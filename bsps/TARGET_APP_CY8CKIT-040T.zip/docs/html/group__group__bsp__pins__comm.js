var group__group__bsp__pins__comm =
[
    [ "CYBSP_I2C_SCL", "group__group__bsp__pins__comm.html#ga034bfe0f68224dd376a9a79e07ab3451", null ],
    [ "CYBSP_I2C_SDA", "group__group__bsp__pins__comm.html#gad178ee7378678fe5829a826f9a4ed0b8", null ],
    [ "CYBSP_SWDIO", "group__group__bsp__pins__comm.html#ga9fba070d4040d6aa4f3e429bdfc38946", null ],
    [ "CYBSP_SWDCK", "group__group__bsp__pins__comm.html#ga8f50aad29445466679abdcc75dcd9796", null ],
    [ "CYBSP_SPI_MOSI", "group__group__bsp__pins__comm.html#ga07b4c8b6a15a1e614ff9be2ebe8088fd", null ]
];