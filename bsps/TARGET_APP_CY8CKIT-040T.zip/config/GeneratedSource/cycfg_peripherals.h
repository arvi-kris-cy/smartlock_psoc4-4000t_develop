/*******************************************************************************
* File Name: cycfg_peripherals.h
*
* Description:
* Peripheral Hardware Block configuration
* This file was automatically generated and should not be modified.
* Configurator Backend 3.10.0
* device-db 4.100.0.4095
* mtb-pdl-cat2 2.6.0.10183
*
********************************************************************************
* Copyright 2023 Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#if !defined(CYCFG_PERIPHERALS_H)
#define CYCFG_PERIPHERALS_H

#include "cycfg_notices.h"
#include "cy_msclp.h"
#include "cy_scb_uart.h"
#include "cy_sysclk.h"
#if defined (CY_USING_HAL)
    #include "cyhal_hwmgr.h"
#endif //defined (CY_USING_HAL)
#include "cy_scb_ezi2c.h"

#if defined(__cplusplus)
extern "C" {
#endif

#define CYBSP_MSC_ENABLED 1U
#define CY_MSCLP0_Cmod1_PORT GPIO_PRT4
#define CY_MSCLP0_Cmod2_PORT GPIO_PRT4
#define CY_MSCLP0_Cmod1_PIN 2u
#define CY_MSCLP0_Cmod2_PIN 3u
#define CY_MSCLP0_Cmod1_PORT_NUM 4u
#define CY_MSCLP0_Cmod2_PORT_NUM 4u
#define Shield0_PORT GPIO_PRT3
#define Proximity0_Sns0_PORT GPIO_PRT2
#define MatrixButtons0_Col0_PORT GPIO_PRT0
#define MatrixButtons0_Col1_PORT GPIO_PRT0
#define MatrixButtons0_Col2_PORT GPIO_PRT0
#define MatrixButtons0_Row0_PORT GPIO_PRT0
#define MatrixButtons0_Row1_PORT GPIO_PRT0
#define MatrixButtons0_Row2_PORT GPIO_PRT2
#define MatrixButtons0_Row3_PORT GPIO_PRT2
#define Shield0_PIN 0u
#define Proximity0_Sns0_PIN 5u
#define MatrixButtons0_Col0_PIN 4u
#define MatrixButtons0_Col1_PIN 3u
#define MatrixButtons0_Col2_PIN 2u
#define MatrixButtons0_Row0_PIN 1u
#define MatrixButtons0_Row1_PIN 0u
#define MatrixButtons0_Row2_PIN 4u
#define MatrixButtons0_Row3_PIN 1u
#define Shield0_PAD P3_0_MSCLP_MSC_GPIO_CTRL_SNS
#define Proximity0_Sns0_PAD P2_5_MSCLP_MSC_GPIO_CTRL_SNS
#define MatrixButtons0_Col0_PAD P0_4_MSCLP_MSC_GPIO_CTRL_SNS
#define MatrixButtons0_Col1_PAD P0_3_MSCLP_MSC_GPIO_CTRL_SNS
#define MatrixButtons0_Col2_PAD P0_2_MSCLP_MSC_GPIO_CTRL_SNS
#define MatrixButtons0_Row0_PAD P0_1_MSCLP_MSC_GPIO_CTRL_SNS
#define MatrixButtons0_Row1_PAD P0_0_MSCLP_MSC_GPIO_CTRL_SNS
#define MatrixButtons0_Row2_PAD P2_4_MSCLP_MSC_GPIO_CTRL_SNS
#define MatrixButtons0_Row3_PAD P2_1_MSCLP_MSC_GPIO_CTRL_SNS
#define CY_MSCLP0_HW MSCLP0
#define CYBSP_MSC_HW MSCLP0
#define CY_MSCLP0_IRQ msclp_interrupt_IRQn
#define CYBSP_MSC_IRQ msclp_interrupt_IRQn
#define CY_MSCLP0_LP_IRQ msclp_interrupt_lp_IRQn
#define CYBSP_MSC_LP_IRQ msclp_interrupt_lp_IRQn
#define CYBSP_CAPSENSE_ENABLED 1U
#define CY_CAPSENSE_CPU_CLK 48000000u
#define CY_CAPSENSE_VDDA_MV 1800u
#define CY_CAPSENSE_CORE 0u
#define CY_MSCLP_CHIP_ID 0u
#define CY_MSCLP_ENABLED_CH_NUMBER 1u
#define CY_MSCLP_MASTER_CHIP_EN 0u
#define CY_MSCLP_COMM_CHIP_EN 0u
#define CY_MSCLP_LITE_CONFIG_EN 0u
#define CY_MSCLP_CHANNEL_OFFSET 0u
#define CY_MSCLP_SW_CONFIG_VER 1u
#define CY_MSCLP_SRAM_SIZE 1024u
#define CY_MSCLP_SENSE_PAD_NUMBER 19u
#define CY_MSCLP_SENSE_MODE_NUMBER 3u
#define CY_MSCLP_PROG_LFSR_PRESENT 1u
#define CY_MSCLP_PROG_LFSR_FL_PRESENT 1u
#define CY_MSCLP_SAMPLE_NUMBER 0u
#define CY_MSCLP_LP_AOC_PRESENT 1u
#define CY_MSCLP_LEGACY_CONN_PRESENT 0u
#define CY_MSCLP_EXT_SYNC_PRESENT 0u
#define CY_MSCLP_DEBUG_PRESENT 1u
#define CY_MSCLP_CSW_GLOBAL_FUNC_NUMBER 8u
#define CY_MSCLP_DMA_PRESENT 0u
#define CY_MSCLP_CMOD34_PRESENT 0u
#define CY_MSCLP_CIC2_PRESENT 1u
#define CY_MSCLP_CH_NUMBER 1u
#define CY_MSCLP_C_FINE_PRESENT 1u
#define CY_MSCLP_C_DITHER_PRESENT 1u
#define CY_MSCLP_PH2_NON_OVERLAP_PRESENT 1u
#define CYBSP_MASTER_SPI_ENABLED 1U
#define CYBSP_MASTER_SPI_HW SCB0
#define CYBSP_MASTER_SPI_IRQ scb_0_interrupt_IRQn
#define CYBSP_EZI2C_ENABLED 1U
#define CYBSP_EZI2C_HW SCB1
#define CYBSP_EZI2C_IRQ scb_1_interrupt_IRQn

extern cy_stc_msclp_context_t cy_msclp_0_context;
extern const cy_stc_scb_uart_config_t CYBSP_MASTER_SPI_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t CYBSP_MASTER_SPI_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_scb_ezi2c_config_t CYBSP_EZI2C_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t CYBSP_EZI2C_obj;
#endif //defined (CY_USING_HAL)

void init_cycfg_peripherals(void);
void reserve_cycfg_peripherals(void);

#if defined(__cplusplus)
}
#endif


#endif /* CYCFG_PERIPHERALS_H */
