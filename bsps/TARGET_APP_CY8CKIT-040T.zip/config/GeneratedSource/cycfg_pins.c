/*******************************************************************************
* File Name: cycfg_pins.c
*
* Description:
* Pin configuration
* This file was automatically generated and should not be modified.
* Configurator Backend 3.10.0
* device-db 4.100.0.4095
* mtb-pdl-cat2 2.6.0.10183
*
********************************************************************************
* Copyright 2023 Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#include "cycfg_pins.h"

const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_COL4_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_TP_COL4_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_COL4_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_COL4_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_COL4_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_COL3_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_TP_COL3_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_COL3_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_COL3_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_COL3_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_COL2_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_TP_COL2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_COL2_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_COL2_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_COL2_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_COL1_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_TP_COL1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_COL1_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_COL1_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_COL1_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_COL0_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_TP_COL0_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_COL0_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_COL0_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_COL0_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CS_Wakeup_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = CS_Wakeup_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CS_Wakeup_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CS_Wakeup_PORT_NUM,
        .channel_num = CS_Wakeup_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t GREEN_LED_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = GREEN_LED_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t GREEN_LED_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = GREEN_LED_PORT_NUM,
        .channel_num = GREEN_LED_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_ROW3_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_TP_ROW3_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_ROW3_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_ROW3_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_ROW3_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_ROW2_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_OD_DRIVESLOW,
    .hsiom = CYBSP_CSD_TP_ROW2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_ROW2_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_ROW2_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_ROW2_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_ROW1_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_OD_DRIVESLOW,
    .hsiom = CYBSP_CSD_TP_ROW1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_ROW1_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_ROW1_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_ROW1_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_TP_ROW0_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_TP_ROW0_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_TP_ROW0_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_TP_ROW0_PORT_NUM,
        .channel_num = CYBSP_CSD_TP_ROW0_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_PROX_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CSD_PROX_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_PROX_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_PROX_PORT_NUM,
        .channel_num = CYBSP_CSD_PROX_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CS_SHIELD_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CS_SHIELD_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CS_SHIELD_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CS_SHIELD_PORT_NUM,
        .channel_num = CYBSP_CS_SHIELD_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_SWDIO_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG,
    .hsiom = CYBSP_SWDIO_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_SWDIO_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_SWDIO_PORT_NUM,
        .channel_num = CYBSP_SWDIO_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_SWDCK_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG,
    .hsiom = CYBSP_SWDCK_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_SWDCK_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_SWDCK_PORT_NUM,
        .channel_num = CYBSP_SWDCK_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_SERIAL_LED_config = 
{
    .outVal = 0,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = CYBSP_SERIAL_LED_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_SERIAL_LED_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_SERIAL_LED_PORT_NUM,
        .channel_num = CYBSP_SERIAL_LED_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CSD_BTN0_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = CYBSP_CSD_BTN0_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CSD_BTN0_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CSD_BTN0_PORT_NUM,
        .channel_num = CYBSP_CSD_BTN0_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CMOD1_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CMOD1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CMOD1_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CMOD1_PORT_NUM,
        .channel_num = CYBSP_CMOD1_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t CYBSP_CMOD2_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = CYBSP_CMOD2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t CYBSP_CMOD2_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = CYBSP_CMOD2_PORT_NUM,
        .channel_num = CYBSP_CMOD2_PIN,
    };
#endif //defined (CY_USING_HAL)


void init_cycfg_pins(void)
{
    Cy_GPIO_Pin_Init(CS_Wakeup_PORT, CS_Wakeup_PIN, &CS_Wakeup_config);
    Cy_GPIO_Pin_Init(GREEN_LED_PORT, GREEN_LED_PIN, &GREEN_LED_config);
    Cy_GPIO_Pin_Init(CYBSP_CSD_TP_ROW2_PORT, CYBSP_CSD_TP_ROW2_PIN, &CYBSP_CSD_TP_ROW2_config);
    Cy_GPIO_Pin_Init(CYBSP_CSD_TP_ROW1_PORT, CYBSP_CSD_TP_ROW1_PIN, &CYBSP_CSD_TP_ROW1_config);
    Cy_GPIO_Pin_Init(CYBSP_SWDIO_PORT, CYBSP_SWDIO_PIN, &CYBSP_SWDIO_config);
    Cy_GPIO_Pin_Init(CYBSP_SWDCK_PORT, CYBSP_SWDCK_PIN, &CYBSP_SWDCK_config);
    Cy_GPIO_Pin_Init(CYBSP_SERIAL_LED_PORT, CYBSP_SERIAL_LED_PIN, &CYBSP_SERIAL_LED_config);
    Cy_GPIO_Pin_Init(CYBSP_CSD_BTN0_PORT, CYBSP_CSD_BTN0_PIN, &CYBSP_CSD_BTN0_config);
}

void reserve_cycfg_pins(void)
{
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_COL4_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_COL3_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_COL2_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_COL1_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_COL0_obj);
    cyhal_hwmgr_reserve(&CS_Wakeup_obj);
    cyhal_hwmgr_reserve(&GREEN_LED_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_ROW3_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_ROW2_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_ROW1_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_TP_ROW0_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_PROX_obj);
    cyhal_hwmgr_reserve(&CYBSP_CS_SHIELD_obj);
    cyhal_hwmgr_reserve(&CYBSP_SWDIO_obj);
    cyhal_hwmgr_reserve(&CYBSP_SWDCK_obj);
    cyhal_hwmgr_reserve(&CYBSP_SERIAL_LED_obj);
    cyhal_hwmgr_reserve(&CYBSP_CSD_BTN0_obj);
    cyhal_hwmgr_reserve(&CYBSP_CMOD1_obj);
    cyhal_hwmgr_reserve(&CYBSP_CMOD2_obj);
#endif //defined (CY_USING_HAL)
}
